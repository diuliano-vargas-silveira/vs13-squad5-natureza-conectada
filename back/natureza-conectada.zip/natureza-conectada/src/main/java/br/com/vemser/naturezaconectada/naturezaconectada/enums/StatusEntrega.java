package br.com.vemser.naturezaconectada.naturezaconectada.enums;

public enum StatusEntrega {
    RECEBIDO, ENVIADO, ENTREGUE;
}